# Android Native Menu Starter

A minimal Android Studio project demonstrating a dark menu UI, toggle controls,
a slider, and a C++ JNI library built with CMake/NDK.

## Requirements
- Android Studio
- Android SDK Platform 35 (or adjust `compileSdk` to an installed SDK)
- Android NDK and CMake 3.22.1 installed from SDK Manager
- JDK supported by your Android Gradle Plugin version

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Install any missing SDK / NDK / CMake components when prompted.
4. Select an emulator or your own Android test device.
5. Press Run.

## Layout
- `app/src/main/java/.../MainActivity.java`: menu UI
- `app/src/main/cpp/menu_core.cpp`: C++ state and JNI functions
- `app/src/main/cpp/CMakeLists.txt`: native build configuration

## Notes
- This is a standalone demonstration app. Toggles update only in-app demo state.
- It does not attach to or modify another app or game, access game memory,
  bypass anti-cheat, or patch protected libraries.
- To add Dear ImGui later, add the upstream Dear ImGui source and its Android/
  OpenGL backend to the project and wire its rendering loop to a dedicated
  native rendering surface. This starter deliberately keeps the first build
  simple and reliable.
