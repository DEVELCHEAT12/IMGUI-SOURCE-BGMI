package com.example.menustarter;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends Activity {
    static { System.loadLibrary("menu_core"); }

    private native String nativeStatus();
    private native void nativeSetOption(String name, boolean enabled);
    private native void nativeSetStrength(int value);

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView label(String text, int size, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(dp(12), dp(8), dp(12), dp(8));
        return v;
    }

    private void addToggle(LinearLayout parent, String title, String key) {
        Switch sw = new Switch(this);
        sw.setText(title);
        sw.setTextColor(Color.WHITE);
        sw.setTextSize(15);
        sw.setPadding(dp(12), dp(10), dp(12), dp(10));
        sw.setOnCheckedChangeListener((button, checked) -> {
            nativeSetOption(key, checked);
            Toast.makeText(this, title + (checked ? " enabled" : " disabled"),
                    Toast.LENGTH_SHORT).show();
        });
        parent.addView(sw, new LinearLayout.LayoutParams(-1, -2));
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(20), dp(16), dp(16));
        page.setBackgroundColor(Color.rgb(12, 18, 30));

        TextView heading = label("NATIVE MENU", 22, Color.rgb(0, 220, 255));
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        page.addView(heading);
        page.addView(label("Standalone UI / JNI demo", 13, Color.LTGRAY));
        page.addView(label("VISUAL OPTIONS", 14, Color.rgb(0, 220, 255)));

        addToggle(page, "Feature One (demo)", "feature_one");
        addToggle(page, "Feature Two (demo)", "feature_two");
        addToggle(page, "Show Status (demo)", "show_status");

        page.addView(label("Demo strength", 15, Color.WHITE));
        SeekBar strength = new SeekBar(this);
        strength.setMax(100);
        strength.setProgress(50);
        page.addView(strength, new LinearLayout.LayoutParams(-1, -2));
        TextView strengthValue = label("Value: 50", 13, Color.LTGRAY);
        page.addView(strengthValue);
        strength.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean user) {
                strengthValue.setText("Value: " + value);
                nativeSetStrength(value);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });

        page.addView(label("NATIVE STATUS", 14, Color.rgb(0, 220, 255)));
        TextView status = label(nativeStatus(), 13, Color.WHITE);
        page.addView(status);

        TextView note = label(
            "Demo controls only. No game process access, memory editing, or anti-cheat changes.",
            12, Color.GRAY);
        page.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(page);
        setContentView(scroll);
    }
}
