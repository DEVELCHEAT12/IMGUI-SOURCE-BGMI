#include <jni.h>
#include <mutex>
#include <string>
#include <unordered_map>

namespace {
    std::mutex g_mutex;
    std::unordered_map<std::string, bool> g_options{
        {"feature_one", false},
        {"feature_two", false},
        {"show_status", true}
    };
    int g_strength = 50;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_menustarter_MainActivity_nativeStatus(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    const std::string status =
        "JNI connected\\n"
        "Feature One: " + std::string(g_options["feature_one"] ? "ON" : "OFF") + "\\n" +
        "Feature Two: " + std::string(g_options["feature_two"] ? "ON" : "OFF") + "\\n" +
        "Strength: " + std::to_string(g_strength);
    return env->NewStringUTF(status.c_str());
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_menustarter_MainActivity_nativeSetOption(
        JNIEnv* env, jobject, jstring name, jboolean enabled) {
    if (name == nullptr) return;
    const char* chars = env->GetStringUTFChars(name, nullptr);
    if (chars == nullptr) return;

    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_options[chars] = (enabled == JNI_TRUE);
    }
    env->ReleaseStringUTFChars(name, chars);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_menustarter_MainActivity_nativeSetStrength(
        JNIEnv*, jobject, jint value) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (value < 0) value = 0;
    if (value > 100) value = 100;
    g_strength = static_cast<int>(value);
}
